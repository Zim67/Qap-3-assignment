import { Link } from "react-router-dom";

const PrivacyPolicyAndTerms = () => {
    return (
      <div className="legalPage">
        <h1>Privacy Policy and Terms of Service</h1>
        <section>
          <h2>Privacy Policy</h2>
          <p>
            Your privacy is important to us. This Privacy Policy explains how we
            collect, use, and disclose your personal information when you use our
            services. By accessing or using our services, you consent to the terms
            of this Privacy Policy.
          </p>
        <br />
          <p>
            Information we collect may include your name, email address, and other
            details you provide when using our website or services. We may use this
            information to communicate with you, improve our services, and provide
            a personalized experience.
          </p>
        <br />
          <p>
            We may also collect anonymous usage data to analyze website traffic and
            enhance user experience. This data does not personally identify you.
          </p>
        <br />
          <p>
            We do not share your personal information with third parties, except
            as required by law or with your consent. We implement security measures
            to protect your data, but please note that no method of transmission
            over the internet is completely secure.
          </p>
        </section>
  
        <section>
          <h2>Terms of Service</h2>
          <p>
            By using our services, you agree to comply with these Terms of Service.
            Do not access or use our services if you do not agree with these terms.
          </p>
        <br />
          <p>
            You may not use our services for any illegal or unauthorized purpose.
            We reserve the right to terminate your access to our services if you
            violate these terms.
          </p>
        <br />
          <p>
            Our services are provided "as is," and we do not make any warranties
            regarding its accuracy, reliability, or availability. We are not
            responsible for any content posted by users or third parties.
          </p>
        <br />
          <p>
            We reserve the right to modify or discontinue our services at any time.
            We may also update these terms from time to time, so please review them
            periodically.
          </p>
        <br />
          <p>
            By using our services, you agree to indemnify and hold us harmless from
            any claims, damages, or liabilities arising from your use of our services
            or violation of these terms.
          </p>
        </section>
        <br />
        <br />
        <center>
          <Link to="/version" className="version-link">
            Version
          </Link>
        <br />
        <br />
        </center>
      </div>
    );
  };
  
  export default PrivacyPolicyAndTerms;