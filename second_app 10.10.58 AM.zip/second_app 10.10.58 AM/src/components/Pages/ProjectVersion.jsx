const ProjectVersion = () => {
  return (
    <>
      <div className="projectVersion">
        <u><b>Last Updated: 07/27/2023</b></u> 
        <br />
        Project Version: 1.0.0.
        </div>
    </>
  );
};

export default ProjectVersion;
