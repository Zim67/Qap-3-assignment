import { Link } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

const Contact = () => {

  const [showMessage, setShowMessage] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setShowMessage(true);

    // Create a new FormData object
    const formData = new FormData(e.target);

    try {
      // Extract values from the form
      const firstName = formData.get("firstName");
      const lastName = formData.get("lastName");
      const email = formData.get("email");
      const phoneNumber = formData.get("phoneNumber");
      const message = formData.get("message");

      const currentTime = new Date();

      const formattedTime = new Intl.DateTimeFormat("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        timeZoneName: "short",
      }).format(currentTime);

      // Create an object with the form data AND current time
      const contactDataObject = {
        firstName,
        lastName,
        email,
        phoneNumber,
        message,
        time: formattedTime,
      };

      // Send the data to the server using POST method
      const response = await axios.post(
        "http://localhost:8000/contactData",
        contactDataObject
      );

      console.log("Data successfully sent to the server:", response.data);
      e.target.reset();
    } catch (error) {
      console.error("Error sending data to the server:", error);
    }

    setTimeout(() => {
      setShowMessage(false);
    }, 3000);
  };

  return (
    <>
      <center>
        {showMessage && <div className="successfulSubmitMsg">Message successfully submitted</div>}
        <div className="contactPage">
          <form className={showMessage ? "formAfterSubmit" : ""} onSubmit={handleSubmit}>
            <label for="firstName"></label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              placeholder="Enter your first name"
              required
            />

            <label for="lastName"></label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              placeholder="Enter your last name"
              required
            />

            <label for="email"></label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Enter your email address"
              required
            />

            <label for="phoneNumber"></label>
            <input
              type="tel"
              id="phoneNumber"
              name="phoneNumber"
              placeholder="Enter your phone number"
              required
            />

            <label for="message"></label>
            <textarea
              id="message"
              name="message"
              rows="4"
              placeholder="Enter your message"
              required
            ></textarea>

            <button type="submit">Submit</button>
          </form>
          <br />
          <br />
          <Link to="/adminlogin" className="version-link">
            Admin Login
          </Link>
          <br />
          <Link to="/version" className="version-link">
            Version
          </Link>
        </div>
      </center>
    </>
  );
};

export default Contact;
