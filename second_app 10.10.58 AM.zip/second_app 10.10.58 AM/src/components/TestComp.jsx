import { useState, useEffect } from "react";
import axios from "axios";

const TestComp = () => {
  const [feedbackDataTest, setFeedbackDataTest] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:5000/feedbackData");
        setFeedbackDataTest(response.data);
      } catch (error) {
        // Handle Error, e.g., display an error message
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleDeleteFeedback = async () => {
    try {
      const response = await axios.delete(
        "http://localhost:5000/feedbackData/2"
      );
      setFeedbackDataTest((prevFeedbackData) =>
        prevFeedbackData.filter((feedback) => feedback.id !== 2)
      );
    } catch (error) {
      console.error("Error deleting data", error);
    }
  };

  return (
    <>
      <div>
        <hr />
        <h1>Feedback Data Test</h1>
        <ul>
          {feedbackDataTest.map((feedback) => (
            <li key={feedback.id}>
              Rating: {feedback.rating}, Comment: {feedback.text}
            </li>
          ))}
        </ul>
        <button onClick={handleDeleteFeedback}>DELETE</button>
      </div>
    </>
  );
};

export default TestComp;
