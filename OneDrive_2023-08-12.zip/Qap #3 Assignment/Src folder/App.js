// App.js

import React from 'react';
import './App.css'; // Import the App.css file

function App() {
  // Your component code here
  return (
    <div className="App">
      {/* Your component content here */}
      <header>
        <h1>Feedback Application</h1>
      </header>
      <nav>
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/contact">Contact</a>
      </nav>
      {/* Additional content */}
    </div>
  );
}

export default App;

  